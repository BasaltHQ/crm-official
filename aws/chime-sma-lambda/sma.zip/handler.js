const { ChimeSDKMeetingsClient, CreateMeetingCommand, CreateAttendeeCommand } = require("@aws-sdk/client-chime-sdk-meetings");

const REGION = process.env.CHIME_REGION || process.env.AWS_REGION || "us-west-2";
const MEETING_REGION = process.env.CHIME_APP_MEETING_REGION || REGION;
const chime = new ChimeSDKMeetingsClient({ region: REGION });

/**
 * SIP Media Application Lambda handler (prototype, CommonJS)
 * Returns { SchemaVersion: "1.0", Actions: [...] } for SMA call flows.
 */
exports.handler = async (event) => {
  console.log("[SMA_EVENT]", JSON.stringify(event));

  const type = event?.InvocationEventType;

  if (type === "NEW_INBOUND_CALL") {
    try {
      const meetingRes = await chime.send(new CreateMeetingCommand({
        ClientRequestToken: `${Date.now()}_${Math.floor(Math.random()*1e9)}`,
        MediaRegion: MEETING_REGION,
        ExternalMeetingId: `sma-${Date.now()}`,
      }));
      const meeting = meetingRes.Meeting;
      if (!meeting || !meeting.MeetingId) {
        return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
      }

      await chime.send(new CreateAttendeeCommand({
        MeetingId: meeting.MeetingId,
        ExternalUserId: `sma-${Math.floor(Math.random() * 1e9)}`,
      }));

      const speak = {
        Type: "Speak",
        Parameters: {
          Text: "Welcome. Please hold while we connect your call.",
          Engine: "neural",
          LanguageCode: "en-US",
          VoiceId: "Joanna",
        },
      };

      // Optional: Bridge the caller to a target endpoint (PSTN or SIP) via SMA
      // Configure CHIME_BRIDGE_ENDPOINT_URI in env (e.g., +17203703285 or sip:bridge@example.com)
      const bridgeUri = process.env.CHIME_BRIDGE_ENDPOINT_URI;
      const actions = [speak];
      if (bridgeUri && bridgeUri.trim()) {
        actions.push({
          Type: "CallAndBridge",
          Parameters: {
            Endpoints: [
              {
                Uri: bridgeUri.trim(),
              },
            ],
            CallTimeoutSeconds: 30,
          },
        });
      }

      return { SchemaVersion: "1.0", Actions: actions };
    } catch (e) {
      console.error("[SMA_NEW_INBOUND_ERROR]", e);
      return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
    }
  }

  if (type === "ACTION_SUCCESS") {
    return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
  }

  return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
};
