import { ChimeSDKMeetingsClient, CreateMeetingCommand, CreateAttendeeCommand } from "@aws-sdk/client-chime-sdk-meetings";

const REGION = process.env.CHIME_REGION || process.env.AWS_REGION || "us-west-2";
const MEETING_REGION = process.env.CHIME_APP_MEETING_REGION || REGION;
const chime = new ChimeSDKMeetingsClient({ region: REGION });

function getEnv(name: string, required = false): string | undefined {
  const v = process.env[name];
  if (required && (!v || !String(v).trim())) throw new Error(`Missing env var: ${name}`);
  return v?.toString().trim();
}

/**
 * SIP Media Application Lambda handler (prototype)
 * Note: SMA events include InvocationEventType values like NEW_INBOUND_CALL, ACTION_SUCCESS, DIGIT_COLLECTION, etc.
 * We return { SchemaVersion: "1.0", Actions: [...] } with actions such as Speak, CallAndBridge, PlayAudio, Hangup.
 * Adjust actions to match your SMA feature set/region.
 */
export const handler = async (event: any) => {
  console.log("[SMA_EVENT]", JSON.stringify(event));

  const type = event?.InvocationEventType;

  // On a new inbound call, create a meeting and provide a basic greeting, then (placeholder) bridge call.
  if (type === "NEW_INBOUND_CALL") {
    try {
      const meetingRes = await chime.send(new CreateMeetingCommand({
        ClientRequestToken: `${Date.now()}_${Math.floor(Math.random() * 1e9)}`,
        MediaRegion: MEETING_REGION,
        ExternalMeetingId: `sma-${Date.now()}`,
      }));
      const meeting = meetingRes.Meeting;
      if (!meeting?.MeetingId) {
        return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
      }

      // Create a dummy attendee for server-side correlation (optional)
      await chime.send(new CreateAttendeeCommand({
        MeetingId: meeting.MeetingId,
        ExternalUserId: `sma-${Math.floor(Math.random() * 1e9)}`,
      }));

      // Speak a greeting to the caller; replace with PlayAudio for custom media or CallAndBridge implementation
      const speak = {
        Type: "Speak",
        Parameters: {
          Text: "Welcome. Please hold while we connect your call.",
          Engine: "neural",
          LanguageCode: "en-US",
          VoiceId: "Joanna",
        },
      };

      const bridgeUri = getEnv("CHIME_BRIDGE_ENDPOINT_URI");
      const callerId = getEnv("CHIME_SOURCE_PHONE") || getEnv("CHIME_SMA_PHONE_NUMBER");
      const actions = bridgeUri
        ? [
            speak,
            {
              Type: "CallAndBridge",
              Parameters: {
                Endpoints: [{ Uri: bridgeUri }],
                CallerIdNumber: callerId,
                CallTimeoutSeconds: 45,
              },
            },
          ]
        : [speak];

      return { SchemaVersion: "1.0", Actions: actions };
    } catch (e) {
      console.error("[SMA_NEW_INBOUND_ERROR]", e);
      return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
    }
  }

  // After an action succeeds, you can continue the flow or hang up.
  if (type === "NEW_OUTBOUND_CALL") {
    const bridgeUri = getEnv("CHIME_BRIDGE_ENDPOINT_URI");
    const callerId = getEnv("CHIME_SOURCE_PHONE") || getEnv("CHIME_SMA_PHONE_NUMBER");
    const actions = bridgeUri
      ? [{
          Type: "CallAndBridge",
          Parameters: {
            Endpoints: [{ Uri: bridgeUri }],
            CallerIdNumber: callerId,
            CallTimeoutSeconds: 45,
          },
        }]
      : [{ Type: "Speak", Parameters: { Text: "Connecting your call.", Engine: "neural", LanguageCode: "en-US", VoiceId: "Joanna" } }];
    return { SchemaVersion: "1.0", Actions: actions };
  }

  if (type === "ACTION_SUCCESS") {
    // Keep the call alive with a short prompt while bridge/media setup completes
    return { SchemaVersion: "1.0", Actions: [{ Type: "Speak", Parameters: { Text: "Please hold.", Engine: "neural", LanguageCode: "en-US", VoiceId: "Joanna" } }] };
  }

  // Default: hang up for unsupported events in this prototype
  return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
};
