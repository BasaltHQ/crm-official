/**
 * Minimal SIP Media Application Lambda handler (CommonJS, no external deps)
 * Responds to NEW_INBOUND_CALL with a greeting, then hangs up on ACTION_SUCCESS.
 * Use this if you want to deploy quickly without bundling node_modules.
 */
exports.handler = async (event) => {
  console.log("[SMA_EVENT]", JSON.stringify(event));
  const type = event && event.InvocationEventType;
  const participants = (event?.CallDetails?.Participants) || [];
  const legA = participants.find((p)=>p.ParticipantTag === "LEG-A");
  const sipHeaders = (event?.ActionData?.Parameters?.SipHeaders) || (event?.CallDetails?.SipHeaders) || (event?.CallDetails?.Attributes) || {};
  const meetingId = sipHeaders?.["X-Meeting-Id"] || sipHeaders?.["x-meeting-id"];
  const attendeeId = sipHeaders?.["X-Attendee-Id"] || sipHeaders?.["x-attendee-id"];
  const joinToken = sipHeaders?.["X-Join-Token"] || sipHeaders?.["x-join-token"];
  const hasChimeJoin = !!(meetingId && attendeeId && joinToken && legA?.CallId);

  if (type === "NEW_INBOUND_CALL") {
    const speak = {
      Type: "Speak",
      Parameters: {
        Text: "Welcome to Ledger1. Please hold while we connect your call.",
        Engine: "neural",
        LanguageCode: "en-US",
        VoiceId: "Joanna",
      },
    };

    const actions = [speak];
    const bridgeUri = process.env.CHIME_BRIDGE_ENDPOINT_URI;
    const callerId = process.env.CHIME_SOURCE_PHONE || process.env.CHIME_SMA_PHONE_NUMBER;
    if (bridgeUri && bridgeUri.trim()) {
      actions.push({
        Type: "CallAndBridge",
        Parameters: {
          Endpoints: [
            {
              Uri: bridgeUri.trim(),
            },
          ],
          CallerIdNumber: callerId,
          CallTimeoutSeconds: 45,
        },
      });
    }
    return { SchemaVersion: "1.0", Actions: actions };
  }

  // Handle outbound SMA-initiated calls (CreateSipMediaApplicationCall)
  if (type === "NEW_OUTBOUND_CALL") {
    return { SchemaVersion: "1.0", Actions: [
      {
        Type: "Speak",
        Parameters: {
          Text: "Please hold.",
          Engine: "neural",
          LanguageCode: "en-US",
          VoiceId: "Joanna",
        },
      },
      {
        Type: "Pause",
        Parameters: { DurationInMilliseconds: 30000 },
      },
    ] };
  }

  // Keep the call alive after answer (defer bridging until gateway is ready)
  if (type === "CALL_ANSWERED") {
    return { SchemaVersion: "1.0", Actions: [
      {
        Type: "Speak",
        Parameters: {
          Text: "Please hold.",
          Engine: "neural",
          LanguageCode: "en-US",
          VoiceId: "Joanna",
        },
      },
      {
        Type: "Pause",
        Parameters: { DurationInMilliseconds: 30000 },
      },
    ] };
  }

  if (type === "ACTION_SUCCESS" || type === "ACTION_SUCCESSFUL") {
    // Keep-alive: provide periodic audio to avoid carrier idle disconnect
    return { SchemaVersion: "1.0", Actions: [
      {
        Type: "Speak",
        Parameters: {
          Text: "Please hold while we connect your call.",
          Engine: "neural",
          LanguageCode: "en-US",
          VoiceId: "Joanna",
        },
      },
      {
        Type: "Pause",
        Parameters: {
          DurationInMilliseconds: 30000,
        },
      },
    ] };
  }

  return { SchemaVersion: "1.0", Actions: [{ Type: "Hangup" }] };
};
